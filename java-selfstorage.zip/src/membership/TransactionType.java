package membership;

public enum TransactionType {
    OPEN, DEPOSIT, RENEW
}
