package StorageService;

public enum StorageType {
    SMALL, MEDIUM, LARGE
}
